package com.group10;

import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;

public class LoginController {
    @FXML
    private AnchorPane rootPane;
}