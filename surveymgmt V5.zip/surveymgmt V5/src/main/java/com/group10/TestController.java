package com.group10;

import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;

public class TestController extends EditQuestionController{
    @FXML
    private AnchorPane rootPane;
}